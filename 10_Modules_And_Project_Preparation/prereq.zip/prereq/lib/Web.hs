{-# LANGUAGE OverloadedStrings #-}

{-|
Dieses Modul enthält den Einstiegspunkt um den Webserver zu starten.
-}
module Web where

import qualified Prereq
import qualified Data.Text.Lazy as T
import           Control.Monad.IO.Class (liftIO)
import           Network.Wai.Middleware.RequestLogger (logStdoutDev)
import           System.Directory (listDirectory)
import           Web.Scotty (file, get, html, middleware, param, post, scotty, setHeader)

-- |Haupteinstiegspunkt, startet den Webserver.
main :: IO ()
main = scotty 4000 $ do
  middleware logStdoutDev

  get "/" $ file "static/index.html"

  get "/styles.css" $ do
    setHeader "Content-Type" "text/css"
    file "static/styles.css"

  post "/content" $ do
    name <- param "textcontent" -- Parameter aus dem Form
    -- IO Actions müssen mit liftIO zu einer ActionM 'angehoben' werden
    liftIO (writeFile "data/upload.txt" name)
    html (T.pack (Prereq.createPage ("Wrote " ++ name ++ " to data/upload.txt")))

  get "/list/:foldername" $ do
    folderName <- param "foldername"
    files <- liftIO (listDirectory folderName)
    html (T.pack (Prereq.createPage ("Number of files: " ++ show (length files) ++ " in " ++ folderName)))

