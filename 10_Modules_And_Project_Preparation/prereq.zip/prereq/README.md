# prereq

Mit diesem kleinen Web-Projekt stellen Sie sicher, dass Sie für die kommende Projektarbeit gut vorbereitet sind.

Die Applikation verwendet [Scotty](https://hackage.haskell.org/package/scotty-0.12/docs/Web-Scotty.html), ein minimales Webframework.


## Kompilieren und Ausführen

###  Versionen überprüfen
Diese Applikation kompiliert mit GHC Version 8.10.7 und Cabal 3.4.0.0 oder 3.6.2.0.
```
> ghc --version
The Glorious Glasgow Haskell Compilation System, version 8.10.7
```
Die GHC Version ist zwingend einzuhalten.

```
> cabal --version
cabal-install version 3.4.0.0
compiled using version 3.4.0.0 of the Cabal library
```
oder
```
cabal-install version 3.6.2.0
compiled using version 3.6.2.0 of the Cabal library 
```
Bei der Build-Tool Installation ist die Situation weniger kritisch. Verwenden Sie entweder 3.4.0.0 oder die aktuell empfohlene Version cabal 3.6.2.0.

Jedes Studierendenprojekt muss schlussendlich von jedem Studierenden kompiliert und ausgeführt werden können.
Falls Sie abweichende Versionen installiert haben, sollten Sie das korrigieren und die beiden Tools, wie in der 1. Lerneinheit erklärt, in den genannten Version aufsetzen.

### Build

Auf Windows werden die folgenden Kommandos am einfachsten in der [Git-Bash](https://git-scm.com/download/win) ausgeführt. Wenn Sie auf Windows aber bereits in WSL Haskell entwickelt haben, ist das genauso gut. Auf OSX und Linux verwenden Sie das übliche Terminal.

1. Package Datenbank aktualisieren:
```
> cabal update
```

2. Build und Run (das dauert beim ersten Mal ziemlich lange, da ein ganzer Webserver kompiliert wird. Da Build-Artefakte aber gecached werden, sind die folgenden Builds dann sehr viel schneller.)
```
> cabal run prereq
```
Wenn die Applikation läuft, können Sie mit dem Browser unter folgender Adresse damit interagieren: http://localhost:4000

3. Tests ausführen
```
> cabal run prereq-test
```

### Bei Problemen
Sollte es Probleme beim Build oder der Ausführung des Projekts kommen, bitte ich Sie diese präzise auf MS Teams zu erklären. Am besten zeigen Sie dabei die Ausgaben der Versionen und dann die Fehlermeldung. Die Fehlermeldung fügen Sie bitte als Text und nicht als Screenshot ein. Es würde mich auch sehr freuen, wenn Sie sich gegenseitig helfen würden.


## Hinweise zum Code

```haskell
($) :: (a -> b) -> a -> b infixr 0
```
Application operator. This operator is redundant, since ordinary application `(f x)` means the same as `(f $ x)`. However, `$` has low, right-associative binding precedence, so it sometimes allows parentheses to be omitted; for example:

```haskell
f $ g $ h x  =  f (g (h x))
```
It is also useful in higher-order situations, such as `map ($ 0) xs`, or `zipWith ($) fs xs`.

----

Scotty verwendet nicht `type String = [Char]` sondern `Text` als Repräsentation für Text. 
Sie können zwischen diesen beiden Typen konvertieren:
```haskell
T.pack :: String -> T.Text
T.unpack :: T.Text -> String
```
Text können Sie mit `<>` konkatenieren und mit `mconcat` können Sie ganze Listen zusammenfügen.
Ich schlage allerdings vor, dass Sie mit `String` operieren und nur gerade an der Schnittstelle zu `T.Text` konvertieren.

Dank der Language-Extension `{-# LANGUAGE OverloadedStrings #-}` können `String` Literale automatisch als `Text` interpretiert werden. 

----

`IO`-Actions in Scotty müssen mit `liftIO` zu `ActionM` konvertiert werden. `ActionM` ist wie ein `IO`-Rezept, kann aber noch mehr. Sie können solche `ActionM` Rezepte analog zu den `IO`-Actions mittels `do`-Notation zu einem grösseren Rezept zusammenfügen.

----

Die Funktionen und Module sind jeweils einen [Haddock](https://haskell-haddock.readthedocs.io/en/latest/markup.html#) Kommentar versehen. Haddock ist ähnlich mächtig wie Javadoc, wir verwenden aber nur minimale Funktionalität.

Die Dokumentation der Library kann mit folgendem Kommando gebaut werden:
```
> cabal haddock
```
Im Output steht dann ein Link auf das generierte HTML.

---- 