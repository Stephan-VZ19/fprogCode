{-# LANGUAGE OverloadedStrings #-}

{-|
Dieses Modul enthält den Einstiegspunkt um die Applikation zu starten.
-}
module Main where

import qualified Web

-- |Haupteinstiegspunkt, startet die Applikation.
main :: IO ()
main = Web.main