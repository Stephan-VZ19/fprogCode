module Main where

import qualified Hadoo.Web

main :: IO ()
main = Hadoo.Web.main